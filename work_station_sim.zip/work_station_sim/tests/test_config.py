import inspect
from pathlib import Path

import pytest

import remote_job_runner as rjr


def write_config(tmp_path: Path, text: str) -> Path:
    path = tmp_path / "config.yaml"
    path.write_text(text, encoding="utf-8")
    return path


def valid_config_text(source_dir: Path) -> str:
    return f"""
remote:
  host: "example.com"
  username: "alice"
  remote_base_dir: "/tmp/remote_job_runner"
job:
  source_dir: "{source_dir.as_posix()}"
stages:
  - name: "prepare"
    mode: "sequential"
    commands:
      - name: "echo"
        cmd: "echo ok"
"""


def test_valid_config_can_load(tmp_path: Path) -> None:
    source = tmp_path / "src"
    source.mkdir()
    config = rjr.load_config(write_config(tmp_path, valid_config_text(source)))

    assert config.remote.host == "example.com"
    assert config.remote.port == 22
    assert config.job.keep_backup is True
    assert config.transfer.include_globs == ["**/*"]
    assert config.stages[0].commands[0].timeout_sec == 3600


def test_missing_remote_host_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace('  host: "example.com"\n', "")
    with pytest.raises(rjr.ConfigError, match="remote.host"):
        rjr.load_config(write_config(tmp_path, text))


def test_missing_remote_username_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace('  username: "alice"\n', "")
    with pytest.raises(rjr.ConfigError, match="remote.username"):
        rjr.load_config(write_config(tmp_path, text))


def test_missing_job_source_dir_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace(f'  source_dir: "{tmp_path.as_posix()}"\n', "")
    with pytest.raises(rjr.ConfigError, match="job.source_dir"):
        rjr.load_config(write_config(tmp_path, text))


def test_invalid_stage_mode_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace('    mode: "sequential"', '    mode: "invalid"')
    with pytest.raises(rjr.ConfigError, match="mode"):
        rjr.load_config(write_config(tmp_path, text))


def test_command_missing_cmd_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace('        cmd: "echo ok"\n', "")
    with pytest.raises(rjr.ConfigError, match="cmd"):
        rjr.load_config(write_config(tmp_path, text))


def test_command_timeout_must_be_positive(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace('        cmd: "echo ok"', '        cmd: "echo ok"\n        timeout_sec: 0')
    with pytest.raises(rjr.ConfigError, match="timeout_sec"):
        rjr.load_config(write_config(tmp_path, text))


def test_password_does_not_appear_in_resolved_config_dump(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("WORKSTATION_PASSWORD", "super-secret")
    text = valid_config_text(tmp_path).replace(
        "stages:",
        'auth:\n  password_env: "WORKSTATION_PASSWORD"\nstages:',
    )
    config = rjr.load_config(write_config(tmp_path, text))
    dumped = rjr.dump_resolved_config_yaml(config)

    assert "super-secret" not in dumped
    assert "WORKSTATION_PASSWORD" in dumped


def test_auth_password_string_can_load_and_is_redacted(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace(
        "stages:",
        'auth:\n  password: "12345"\nstages:',
    )

    config = rjr.load_config(write_config(tmp_path, text))
    dumped = rjr.dump_resolved_config_yaml(config)

    assert config.auth.password == "12345"
    assert "12345" not in dumped
    assert "<redacted>" in dumped


def test_auth_password_integer_is_converted_to_string(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace(
        "stages:",
        "auth:\n  password: 12345\nstages:",
    )

    config = rjr.load_config(write_config(tmp_path, text))

    assert config.auth.password == "12345"


def test_auth_password_boolean_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace(
        "stages:",
        "auth:\n  password: true\nstages:",
    )

    with pytest.raises(rjr.ConfigError, match="auth.password"):
        rjr.load_config(write_config(tmp_path, text))


def test_auth_password_empty_string_raises_config_error(tmp_path: Path) -> None:
    text = valid_config_text(tmp_path).replace(
        "stages:",
        'auth:\n  password: ""\nstages:',
    )

    with pytest.raises(rjr.ConfigError, match="auth.password"):
        rjr.load_config(write_config(tmp_path, text))


def test_resolve_auth_priority(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    key_file = tmp_path / "id_ed25519"
    monkeypatch.setenv("WORKSTATION_PASSWORD", "from-env")

    assert rjr.resolve_auth(rjr.AuthConfig(key_file, "direct-password", "WORKSTATION_PASSWORD")) == (
        str(key_file),
        None,
    )
    assert rjr.resolve_auth(rjr.AuthConfig(None, "direct-password", "WORKSTATION_PASSWORD")) == (
        None,
        "direct-password",
    )


def test_password_env_missing_still_raises_config_error(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("WORKSTATION_PASSWORD", raising=False)

    with pytest.raises(rjr.ConfigError, match="WORKSTATION_PASSWORD"):
        rjr.resolve_auth(rjr.AuthConfig(None, None, "WORKSTATION_PASSWORD"))


def test_yaml_safe_load_is_used(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "src"
    source.mkdir()
    calls = {"safe": 0}
    real_safe_load = rjr.yaml.safe_load

    def fake_safe_load(stream):
        calls["safe"] += 1
        return real_safe_load(stream)

    monkeypatch.setattr(rjr.yaml, "safe_load", fake_safe_load)

    rjr.load_config(write_config(tmp_path, valid_config_text(source)))

    source_text = inspect.getsource(rjr.load_config)
    assert calls == {"safe": 1}
    assert "yaml.safe_load" in source_text
    assert "yaml.load(" not in source_text
