import hashlib
from pathlib import Path

import pytest

import remote_job_runner as rjr


def rels(entries: list[rjr.FileManifestEntry]) -> set[str]:
    return {entry.relative_path for entry in entries}


def test_recursive_scan_finds_nested_files(tmp_path: Path) -> None:
    (tmp_path / "a" / "b").mkdir(parents=True)
    (tmp_path / "a" / "b" / "file.txt").write_text("x", encoding="utf-8")

    entries = rjr.build_manifest(tmp_path, ["**/*"], [], True, False)

    assert "a/b/file.txt" in rels(entries)


def test_hidden_files_are_included(tmp_path: Path) -> None:
    (tmp_path / ".env").write_text("secret-name-only", encoding="utf-8")

    entries = rjr.build_manifest(tmp_path, ["**/*"], [], True, False)

    assert ".env" in rels(entries)


def test_exclude_globs_can_exclude_files(tmp_path: Path) -> None:
    (tmp_path / "keep.txt").write_text("keep", encoding="utf-8")
    (tmp_path / "drop.tmp").write_text("drop", encoding="utf-8")

    entries = rjr.build_manifest(tmp_path, ["**/*"], ["*.tmp"], True, False)

    assert "keep.txt" in rels(entries)
    assert "drop.tmp" not in rels(entries)


def test_include_globs_can_limit_files(tmp_path: Path) -> None:
    (tmp_path / "a.txt").write_text("a", encoding="utf-8")
    (tmp_path / "b.log").write_text("b", encoding="utf-8")

    entries = rjr.build_manifest(tmp_path, ["*.txt"], [], True, False)

    assert "a.txt" in rels(entries)
    assert "b.log" not in rels(entries)


def test_directory_entries_are_recorded(tmp_path: Path) -> None:
    (tmp_path / "empty").mkdir()

    entries = rjr.build_manifest(tmp_path, ["**/*"], [], True, False)
    directory_entries = {entry.relative_path for entry in entries if entry.kind == "directory"}

    assert "." in directory_entries
    assert "empty" in directory_entries


def test_verify_hash_true_calculates_sha256(tmp_path: Path) -> None:
    target = tmp_path / "file.txt"
    target.write_text("abc", encoding="utf-8")

    entries = rjr.build_manifest(tmp_path, ["**/*"], [], True, False)
    file_entry = next(entry for entry in entries if entry.relative_path == "file.txt")

    assert file_entry.sha256 == hashlib.sha256(b"abc").hexdigest()


def test_verify_hash_false_sets_sha256_none(tmp_path: Path) -> None:
    (tmp_path / "file.txt").write_text("abc", encoding="utf-8")

    entries = rjr.build_manifest(tmp_path, ["**/*"], [], False, False)
    file_entry = next(entry for entry in entries if entry.relative_path == "file.txt")

    assert file_entry.sha256 is None


def test_symlink_raises_when_not_skipped(tmp_path: Path) -> None:
    target = tmp_path / "target.txt"
    target.write_text("x", encoding="utf-8")
    link = tmp_path / "link.txt"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symlink unavailable in this environment: {exc}")

    with pytest.raises(rjr.TransferError, match="Symlink"):
        rjr.build_manifest(tmp_path, ["**/*"], [], True, False)


def test_symlink_skipped_when_enabled(tmp_path: Path) -> None:
    target = tmp_path / "target.txt"
    target.write_text("x", encoding="utf-8")
    link = tmp_path / "link.txt"
    try:
        link.symlink_to(target)
    except (OSError, NotImplementedError) as exc:
        pytest.skip(f"symlink unavailable in this environment: {exc}")

    entries = rjr.build_manifest(tmp_path, ["**/*"], [], True, True)

    assert "target.txt" in rels(entries)
    assert "link.txt" not in rels(entries)
