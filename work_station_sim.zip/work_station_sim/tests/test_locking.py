import json
import re
from pathlib import Path

import pytest

import remote_job_runner as rjr


def test_lock_can_be_created_and_removed(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    lock_path = rjr.lock_file_path(source)

    with rjr.acquire_lock(source):
        assert lock_path.exists()

    assert not lock_path.exists()


def test_existing_lock_raises_lock_error(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    lock_path = rjr.lock_file_path(source)
    lock_path.write_text("existing", encoding="utf-8")

    with pytest.raises(rjr.LockError, match=re.escape(str(lock_path))):
        with rjr.acquire_lock(source):
            pass


def test_lock_content_contains_pid_timestamp_source_dir(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    lock_path = rjr.lock_file_path(source)

    with rjr.acquire_lock(source):
        data = json.loads(lock_path.read_text(encoding="utf-8"))

    assert isinstance(data["pid"], int)
    assert data["timestamp"]
    assert data["source_dir"] == str(source)


def test_lock_removed_when_context_raises_exception(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    lock_path = rjr.lock_file_path(source)

    with pytest.raises(RuntimeError):
        with rjr.acquire_lock(source):
            raise RuntimeError("boom")

    assert not lock_path.exists()
