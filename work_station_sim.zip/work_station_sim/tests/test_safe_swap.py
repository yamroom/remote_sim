from pathlib import Path

import pytest

import remote_job_runner as rjr


def test_successfully_replaces_source_dir(tmp_path: Path) -> None:
    source = tmp_path / "source"
    result = tmp_path / "result"
    backup = tmp_path / "backup"
    source.mkdir()
    result.mkdir()
    (source / "old.txt").write_text("old", encoding="utf-8")
    (result / "new.txt").write_text("new", encoding="utf-8")

    rjr.safe_replace_source_dir(source, result, backup, keep_backup=True)

    assert (source / "new.txt").read_text(encoding="utf-8") == "new"
    assert (backup / "old.txt").read_text(encoding="utf-8") == "old"
    assert not result.exists()


def test_keep_backup_true_retains_backup(tmp_path: Path) -> None:
    source = tmp_path / "source"
    result = tmp_path / "result"
    backup = tmp_path / "backup"
    source.mkdir()
    result.mkdir()

    rjr.safe_replace_source_dir(source, result, backup, keep_backup=True)

    assert backup.exists()


def test_keep_backup_false_deletes_backup(tmp_path: Path) -> None:
    source = tmp_path / "source"
    result = tmp_path / "result"
    backup = tmp_path / "backup"
    source.mkdir()
    result.mkdir()

    rjr.safe_replace_source_dir(source, result, backup, keep_backup=False)

    assert source.exists()
    assert not backup.exists()


def test_result_dir_missing_raises_safe_swap_error(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()

    with pytest.raises(rjr.SafeSwapError, match="result_dir"):
        rjr.safe_replace_source_dir(source, tmp_path / "missing", tmp_path / "backup", True)


def test_backup_dir_existing_raises_safe_swap_error(tmp_path: Path) -> None:
    source = tmp_path / "source"
    result = tmp_path / "result"
    backup = tmp_path / "backup"
    source.mkdir()
    result.mkdir()
    backup.mkdir()

    with pytest.raises(rjr.SafeSwapError, match="backup_dir"):
        rjr.safe_replace_source_dir(source, result, backup, True)


def test_source_dir_missing_raises_safe_swap_error(tmp_path: Path) -> None:
    result = tmp_path / "result"
    result.mkdir()

    with pytest.raises(rjr.SafeSwapError, match="source_dir"):
        rjr.safe_replace_source_dir(tmp_path / "missing", result, tmp_path / "backup", True)


def test_result_rename_failure_rolls_back(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "source"
    result = tmp_path / "result"
    backup = tmp_path / "backup"
    source.mkdir()
    result.mkdir()
    (source / "old.txt").write_text("old", encoding="utf-8")

    real_rename = Path.rename

    def fake_rename(self: Path, target: Path):
        if self == result and target == source:
            raise OSError("simulated result rename failure")
        return real_rename(self, target)

    monkeypatch.setattr(Path, "rename", fake_rename)

    with pytest.raises(rjr.SafeSwapError, match="rollback succeeded"):
        rjr.safe_replace_source_dir(source, result, backup, True)

    assert source.exists()
    assert (source / "old.txt").read_text(encoding="utf-8") == "old"


def test_rollback_failure_mentions_manual_repair(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "source"
    result = tmp_path / "result"
    backup = tmp_path / "backup"
    source.mkdir()
    result.mkdir()

    real_rename = Path.rename

    def fake_rename(self: Path, target: Path):
        if self == result and target == source:
            raise OSError("simulated result rename failure")
        if self == backup and target == source:
            raise OSError("simulated rollback failure")
        return real_rename(self, target)

    monkeypatch.setattr(Path, "rename", fake_rename)

    with pytest.raises(rjr.SafeSwapError, match="manual repair is required"):
        rjr.safe_replace_source_dir(source, result, backup, True)
