from pathlib import Path

import pytest

import remote_job_runner as rjr


def config_for(source: Path) -> rjr.ResolvedConfig:
    return rjr.ResolvedConfig(
        remote=rjr.RemoteConfig("example.com", 22, "alice", "/tmp/remote_job_runner"),
        auth=rjr.AuthConfig(None, None, None),
        job=rjr.JobConfig(source, True, True, False, True, False),
        transfer=rjr.TransferConfig(["**/*"], []),
        stages=[
            rjr.StageSpec(
                "prepare",
                "sequential",
                [rjr.CommandSpec("echo", "echo ok", 60)],
                None,
            )
        ],
    )


def test_dry_run_does_not_create_lock(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()

    rjr.run_dry_run(config_for(source))

    assert not rjr.lock_file_path(source).exists()


def test_dry_run_does_not_call_ssh_connect(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "source"
    source.mkdir()

    def fail_connect(*_args, **_kwargs):
        raise AssertionError("SSH connect must not be called")

    monkeypatch.setattr(rjr, "connect_ssh", fail_connect)

    rjr.run_dry_run(config_for(source))


def test_dry_run_does_not_call_upload(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "source"
    source.mkdir()

    def fail_upload(*_args, **_kwargs):
        raise AssertionError("upload must not be called")

    monkeypatch.setattr(rjr, "upload_manifest", fail_upload)

    rjr.run_dry_run(config_for(source))


def test_dry_run_does_not_call_command_execution(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    source = tmp_path / "source"
    source.mkdir()

    def fail_run_stage(*_args, **_kwargs):
        raise AssertionError("command execution must not be called")

    monkeypatch.setattr(rjr, "run_stage", fail_run_stage)

    rjr.run_dry_run(config_for(source))


def test_dry_run_does_not_modify_source_dir(tmp_path: Path) -> None:
    source = tmp_path / "source"
    source.mkdir()
    original = source / "data.txt"
    original.write_text("unchanged", encoding="utf-8")

    rjr.run_dry_run(config_for(source))

    assert original.read_text(encoding="utf-8") == "unchanged"
    assert sorted(path.name for path in source.iterdir()) == ["data.txt"]


def test_dry_run_output_contains_stages_and_upload_plan(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    source = tmp_path / "source"
    source.mkdir()
    (source / "data.txt").write_text("x", encoding="utf-8")

    rjr.run_dry_run(config_for(source))
    output = capsys.readouterr().out

    assert "upload_plan" in output
    assert "data.txt" in output
    assert "stages" in output
    assert "prepare" in output


def test_dry_run_output_does_not_show_password(tmp_path: Path, capsys: pytest.CaptureFixture[str]) -> None:
    source = tmp_path / "source"
    source.mkdir()
    config = rjr.ResolvedConfig(
        remote=rjr.RemoteConfig("example.com", 22, "alice", "/tmp/remote_job_runner"),
        auth=rjr.AuthConfig(None, "secret-password", None),
        job=rjr.JobConfig(source, True, True, False, True, False),
        transfer=rjr.TransferConfig(["**/*"], []),
        stages=[rjr.StageSpec("prepare", "sequential", [rjr.CommandSpec("echo", "echo ok", 60)], None)],
    )

    rjr.run_dry_run(config)
    output = capsys.readouterr().out

    assert "secret-password" not in output
