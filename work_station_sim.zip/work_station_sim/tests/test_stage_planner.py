from pathlib import Path

import pytest

import remote_job_runner as rjr


def result(stage: str, command: rjr.CommandSpec, exit_code: int = 0) -> rjr.CommandResult:
    return rjr.CommandResult(
        stage_name=stage,
        command_name=command.name,
        command=command.cmd,
        start_time="start",
        end_time="end",
        duration_sec=0.01,
        exit_code=exit_code,
        stdout="",
        stderr="",
        timed_out=False,
    )


def test_sequential_stage_runs_in_order(tmp_path: Path) -> None:
    calls: list[str] = []
    commands = [rjr.CommandSpec("a", "echo a"), rjr.CommandSpec("b", "echo b")]
    stage = rjr.StageSpec("s", "sequential", commands)

    def runner(_ssh, _wd, command, stage_name, _log_dir):
        calls.append(command.name)
        return result(stage_name, command)

    stage_result = rjr.run_stage(None, "/tmp/job", stage, tmp_path, runner=runner)

    assert stage_result.success is True
    assert calls == ["a", "b"]


def test_sequential_stage_stops_after_failure(tmp_path: Path) -> None:
    calls: list[str] = []
    commands = [rjr.CommandSpec("a", "false"), rjr.CommandSpec("b", "echo b")]
    stage = rjr.StageSpec("s", "sequential", commands)

    def runner(_ssh, _wd, command, stage_name, _log_dir):
        calls.append(command.name)
        return result(stage_name, command, exit_code=1 if command.name == "a" else 0)

    stage_result = rjr.run_stage(None, "/tmp/job", stage, tmp_path, runner=runner)

    assert stage_result.success is False
    assert calls == ["a"]


def test_parallel_stage_runs_all_commands(tmp_path: Path) -> None:
    calls: set[str] = set()
    commands = [rjr.CommandSpec("a", "echo a"), rjr.CommandSpec("b", "echo b")]
    stage = rjr.StageSpec("s", "parallel", commands, max_workers=2)

    def runner(_ssh, _wd, command, stage_name, _log_dir):
        calls.add(command.name)
        return result(stage_name, command)

    stage_result = rjr.run_stage(None, "/tmp/job", stage, tmp_path, runner=runner)

    assert stage_result.success is True
    assert calls == {"a", "b"}


def test_parallel_stage_failure_marks_stage_failed(tmp_path: Path) -> None:
    commands = [rjr.CommandSpec("a", "echo a"), rjr.CommandSpec("b", "false")]
    stage = rjr.StageSpec("s", "parallel", commands, max_workers=2)

    def runner(_ssh, _wd, command, stage_name, _log_dir):
        return result(stage_name, command, exit_code=1 if command.name == "b" else 0)

    stage_result = rjr.run_stage(None, "/tmp/job", stage, tmp_path, runner=runner)

    assert stage_result.success is False


def test_parallel_results_are_sorted_by_config_order(tmp_path: Path) -> None:
    commands = [rjr.CommandSpec("first", "echo first"), rjr.CommandSpec("second", "echo second")]
    stage = rjr.StageSpec("s", "parallel", commands, max_workers=2)

    def runner(_ssh, _wd, command, stage_name, _log_dir):
        return result(stage_name, command)

    stage_result = rjr.run_stage(None, "/tmp/job", stage, tmp_path, runner=runner)

    assert [item.command_name for item in stage_result.command_results] == ["first", "second"]


def test_max_workers_default_is_valid(tmp_path: Path) -> None:
    text = f"""
remote:
  host: "example.com"
  username: "alice"
  remote_base_dir: "/tmp"
job:
  source_dir: "{tmp_path.as_posix()}"
stages:
  - name: "p"
    mode: "parallel"
    commands:
      - name: "a"
        cmd: "echo a"
      - name: "b"
        cmd: "echo b"
"""
    path = tmp_path / "config.yaml"
    path.write_text(text, encoding="utf-8")

    config = rjr.load_config(path)

    assert config.stages[0].max_workers == 2


def test_invalid_max_workers_raises_config_error(tmp_path: Path) -> None:
    text = f"""
remote:
  host: "example.com"
  username: "alice"
  remote_base_dir: "/tmp"
job:
  source_dir: "{tmp_path.as_posix()}"
stages:
  - name: "p"
    mode: "parallel"
    max_workers: 0
    commands:
      - name: "a"
        cmd: "echo a"
"""
    path = tmp_path / "config.yaml"
    path.write_text(text, encoding="utf-8")

    with pytest.raises(rjr.ConfigError, match="max_workers"):
        rjr.load_config(path)
