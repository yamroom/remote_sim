#!/usr/bin/env python3
"""
remote_job_runner.py

A production-oriented single-file CLI tool for staging a local folder on a
remote Linux workstation, running sequential/parallel command stages there,
then safely replacing the original local folder with the returned results.

Design priorities:
- Never destroy the original source_dir before a verified replacement exists.
- Keep secrets out of logs and resolved config dumps.
- Use safe YAML loading.
- Make core logic testable without a real SSH server.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import contextlib
import dataclasses
import datetime as _dt
import fnmatch
import getpass
import hashlib
import json
import logging
import os
import posixpath
import re
import shlex
import shutil
import socket
import stat as stat_mod
import sys
import tempfile
import time
import uuid
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterator, Literal, Optional, Sequence

try:
    import yaml
except ImportError as exc:  # pragma: no cover - exercised only when dependency missing
    raise SystemExit("Missing dependency: PyYAML. Install with: pip install PyYAML") from exc

try:
    import paramiko
except ImportError:  # pragma: no cover - dry-run/config tests may not need it
    paramiko = None  # type: ignore[assignment]


# =============================================================================
# Exceptions
# =============================================================================


class RemoteJobRunnerError(Exception):
    """Base class for all remote job runner errors."""


class ConfigError(RemoteJobRunnerError):
    """Configuration is missing, invalid, or unsafe."""


class ConnectionError(RemoteJobRunnerError):
    """SSH/SFTP connection failure."""


class TransferError(RemoteJobRunnerError):
    """Upload/download/manifest transfer failure."""


class RemoteCommandError(RemoteJobRunnerError):
    """Remote command execution failure."""


class VerificationError(RemoteJobRunnerError):
    """Downloaded result verification failure."""


class SafeSwapError(RemoteJobRunnerError):
    """Safe replacement of source_dir failed."""


class LockError(RemoteJobRunnerError):
    """A source_dir lock already exists or cannot be created."""


# =============================================================================
# Dataclasses
# =============================================================================


@dataclass(frozen=True)
class RemoteConfig:
    host: str
    port: int
    username: str
    remote_base_dir: str


@dataclass(frozen=True)
class AuthConfig:
    key_file: Optional[Path] = None
    password_env: Optional[str] = None


@dataclass(frozen=True)
class JobConfig:
    source_dir: Path
    keep_backup: bool = True
    cleanup_remote_on_success: bool = True
    cleanup_remote_on_failure: bool = False
    verify_hash: bool = True
    skip_symlinks: bool = False


@dataclass(frozen=True)
class TransferConfig:
    include_globs: list[str]
    exclude_globs: list[str]


@dataclass(frozen=True)
class CommandSpec:
    name: str
    cmd: str
    timeout_sec: int = 3600


@dataclass(frozen=True)
class StageSpec:
    name: str
    mode: Literal["sequential", "parallel"]
    commands: list[CommandSpec]
    max_workers: Optional[int] = None


@dataclass(frozen=True)
class ResolvedConfig:
    remote: RemoteConfig
    auth: AuthConfig
    job: JobConfig
    transfer: TransferConfig
    stages: list[StageSpec]
    auto_add_host_key: bool = False


@dataclass(frozen=True)
class FileManifestEntry:
    relative_path: str
    kind: Literal["file", "directory"]
    size: int
    sha256: Optional[str]
    mtime_ns: int


@dataclass(frozen=True)
class CommandResult:
    stage_name: str
    command_name: str
    command: str
    start_time: str
    end_time: str
    duration_sec: float
    exit_code: int
    stdout: str
    stderr: str
    timed_out: bool

    @property
    def success(self) -> bool:
        return self.exit_code == 0 and not self.timed_out


@dataclass(frozen=True)
class StageResult:
    stage_name: str
    mode: str
    command_results: list[CommandResult]
    success: bool


@dataclass(frozen=True)
class JobResult:
    job_id: str
    success: bool
    remote_workdir: str
    local_log_dir: Path
    backup_dir: Optional[Path]
    stage_results: list[StageResult]


# =============================================================================
# Utility functions
# =============================================================================


def utc_now_iso() -> str:
    return _dt.datetime.now(_dt.timezone.utc).isoformat(timespec="seconds")


def make_job_id() -> str:
    stamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid = uuid.uuid4().hex[:8]
    return f"job_{stamp}_{short_uuid}"


def sanitize_filename(value: str, fallback: str = "unnamed") -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_.-]+", "_", value).strip("._")
    return cleaned or fallback


def dataclass_to_plain(obj: Any) -> Any:
    """Convert dataclasses and Paths into JSON/YAML-serializable values."""
    if dataclasses.is_dataclass(obj):
        return {field.name: dataclass_to_plain(getattr(obj, field.name)) for field in dataclasses.fields(obj)}
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, list):
        return [dataclass_to_plain(item) for item in obj]
    if isinstance(obj, tuple):
        return [dataclass_to_plain(item) for item in obj]
    if isinstance(obj, dict):
        return {str(key): dataclass_to_plain(value) for key, value in obj.items()}
    return obj


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def read_yaml_file(path: Path) -> dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise ConfigError(f"Cannot read config file: {path}: {exc}") from exc
    try:
        loaded = yaml.safe_load(text)  # Required: safe YAML loading only.
    except yaml.YAMLError as exc:
        raise ConfigError(f"Invalid YAML config: {path}: {exc}") from exc
    if loaded is None:
        return {}
    if not isinstance(loaded, dict):
        raise ConfigError("Config root must be a YAML mapping/object.")
    return loaded


def nested_get(data: dict[str, Any], path: Sequence[str], default: Any = None) -> Any:
    cur: Any = data
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return default
        cur = cur[key]
    return cur


def nested_set(data: dict[str, Any], path: Sequence[str], value: Any) -> None:
    cur: dict[str, Any] = data
    for key in path[:-1]:
        child = cur.get(key)
        if not isinstance(child, dict):
            child = {}
            cur[key] = child
        cur = child
    cur[path[-1]] = value


def require_str(data: dict[str, Any], path: Sequence[str], label: str) -> str:
    value = nested_get(data, path)
    if not isinstance(value, str) or not value.strip():
        raise ConfigError(f"Missing or invalid required config field: {label}")
    return value.strip()


def get_bool(data: dict[str, Any], path: Sequence[str], default: bool) -> bool:
    value = nested_get(data, path, default)
    if isinstance(value, bool):
        return value
    raise ConfigError(f"Expected boolean for config field: {'.'.join(path)}")


def get_int(data: dict[str, Any], path: Sequence[str], default: int, *, minimum: Optional[int] = None) -> int:
    value = nested_get(data, path, default)
    if not isinstance(value, int):
        raise ConfigError(f"Expected integer for config field: {'.'.join(path)}")
    if minimum is not None and value < minimum:
        raise ConfigError(f"Expected {'.'.join(path)} >= {minimum}, got {value}")
    return value


def get_str_list(data: dict[str, Any], path: Sequence[str], default: list[str]) -> list[str]:
    value = nested_get(data, path, default)
    if value is None:
        return list(default)
    if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
        raise ConfigError(f"Expected list[str] for config field: {'.'.join(path)}")
    return list(value)


# =============================================================================
# Config loading and validation
# =============================================================================


def parse_stage(stage_raw: Any, index: int) -> StageSpec:
    if not isinstance(stage_raw, dict):
        raise ConfigError(f"Stage #{index + 1} must be a mapping/object.")
    name = stage_raw.get("name")
    if not isinstance(name, str) or not name.strip():
        raise ConfigError(f"Stage #{index + 1} missing required field: name")
    mode = stage_raw.get("mode")
    if mode not in {"sequential", "parallel"}:
        raise ConfigError(f"Stage '{name}' has invalid mode: {mode!r}; expected sequential or parallel")
    commands_raw = stage_raw.get("commands")
    if not isinstance(commands_raw, list) or not commands_raw:
        raise ConfigError(f"Stage '{name}' must contain at least one command.")

    commands: list[CommandSpec] = []
    for cmd_index, cmd_raw in enumerate(commands_raw):
        if not isinstance(cmd_raw, dict):
            raise ConfigError(f"Command #{cmd_index + 1} in stage '{name}' must be a mapping/object.")
        cmd_name = cmd_raw.get("name")
        cmd_text = cmd_raw.get("cmd")
        if not isinstance(cmd_name, str) or not cmd_name.strip():
            raise ConfigError(f"Command #{cmd_index + 1} in stage '{name}' missing required field: name")
        if not isinstance(cmd_text, str) or not cmd_text.strip():
            raise ConfigError(f"Command '{cmd_name}' in stage '{name}' missing required field: cmd")
        timeout_sec = cmd_raw.get("timeout_sec", 3600)
        if not isinstance(timeout_sec, int) or timeout_sec <= 0:
            raise ConfigError(f"Command '{cmd_name}' in stage '{name}' requires timeout_sec > 0")
        commands.append(CommandSpec(name=cmd_name.strip(), cmd=cmd_text, timeout_sec=timeout_sec))

    max_workers: Optional[int] = stage_raw.get("max_workers")
    if max_workers is not None:
        if not isinstance(max_workers, int) or max_workers < 1:
            raise ConfigError(f"Stage '{name}' requires max_workers >= 1")
    if mode == "parallel" and max_workers is None:
        max_workers = min(4, len(commands))

    return StageSpec(name=name.strip(), mode=mode, commands=commands, max_workers=max_workers)  # type: ignore[arg-type]


def load_config(config_path: Path, overrides: Optional[argparse.Namespace] = None) -> ResolvedConfig:
    raw = read_yaml_file(config_path)

    if overrides is not None:
        cli_map: list[tuple[str, tuple[str, ...]]] = [
            ("host", ("remote", "host")),
            ("port", ("remote", "port")),
            ("username", ("remote", "username")),
            ("remote_base_dir", ("remote", "remote_base_dir")),
            ("password_env", ("auth", "password_env")),
            ("key_file", ("auth", "key_file")),
            ("source_dir", ("job", "source_dir")),
        ]
        for attr, path in cli_map:
            value = getattr(overrides, attr, None)
            if value is not None:
                nested_set(raw, path, value)
        if getattr(overrides, "keep_backup", None) is not None:
            nested_set(raw, ("job", "keep_backup"), overrides.keep_backup)
        if getattr(overrides, "cleanup_remote_on_success", None) is not None:
            nested_set(raw, ("job", "cleanup_remote_on_success"), overrides.cleanup_remote_on_success)
        if getattr(overrides, "cleanup_remote_on_failure", None) is not None:
            nested_set(raw, ("job", "cleanup_remote_on_failure"), overrides.cleanup_remote_on_failure)

    remote = RemoteConfig(
        host=require_str(raw, ("remote", "host"), "remote.host"),
        port=get_int(raw, ("remote", "port"), 22, minimum=1),
        username=require_str(raw, ("remote", "username"), "remote.username"),
        remote_base_dir=require_str(raw, ("remote", "remote_base_dir"), "remote.remote_base_dir"),
    )

    key_file_raw = nested_get(raw, ("auth", "key_file"))
    key_file = Path(os.path.expanduser(key_file_raw)).resolve() if isinstance(key_file_raw, str) and key_file_raw.strip() else None
    password_env_raw = nested_get(raw, ("auth", "password_env"))
    if password_env_raw is not None and (not isinstance(password_env_raw, str) or not password_env_raw.strip()):
        raise ConfigError("auth.password_env must be a non-empty string when provided.")
    auth = AuthConfig(key_file=key_file, password_env=password_env_raw.strip() if isinstance(password_env_raw, str) else None)

    source_dir = Path(os.path.expanduser(require_str(raw, ("job", "source_dir"), "job.source_dir"))).resolve()
    job = JobConfig(
        source_dir=source_dir,
        keep_backup=get_bool(raw, ("job", "keep_backup"), True),
        cleanup_remote_on_success=get_bool(raw, ("job", "cleanup_remote_on_success"), True),
        cleanup_remote_on_failure=get_bool(raw, ("job", "cleanup_remote_on_failure"), False),
        verify_hash=get_bool(raw, ("job", "verify_hash"), True),
        skip_symlinks=get_bool(raw, ("job", "skip_symlinks"), False),
    )

    transfer = TransferConfig(
        include_globs=get_str_list(raw, ("transfer", "include_globs"), ["**/*"]),
        exclude_globs=get_str_list(raw, ("transfer", "exclude_globs"), []),
    )

    stages_raw = raw.get("stages")
    if not isinstance(stages_raw, list) or not stages_raw:
        raise ConfigError("Config must contain at least one stage under 'stages'.")
    stages = [parse_stage(stage_raw, index) for index, stage_raw in enumerate(stages_raw)]

    auto_add_host_key = bool(getattr(overrides, "auto_add_host_key", False)) if overrides is not None else False
    return ResolvedConfig(remote=remote, auth=auth, job=job, transfer=transfer, stages=stages, auto_add_host_key=auto_add_host_key)


def dump_resolved_config(config: ResolvedConfig, path: Path) -> None:
    """Dump sanitized resolved config. No runtime password is ever stored in ResolvedConfig."""
    path.parent.mkdir(parents=True, exist_ok=True)
    plain = dataclass_to_plain(config)
    path.write_text(yaml.safe_dump(plain, sort_keys=False, allow_unicode=True), encoding="utf-8")


def resolve_password(auth: AuthConfig) -> Optional[str]:
    """Resolve runtime password without logging or persisting it."""
    if auth.key_file is not None:
        return None
    if auth.password_env:
        if auth.password_env not in os.environ:
            raise ConfigError(f"Password environment variable is not set: {auth.password_env}")
        return os.environ[auth.password_env]
    return getpass.getpass("SSH password: ")


# =============================================================================
# Manifest
# =============================================================================


def normalize_rel_path(path: Path) -> str:
    return path.as_posix().lstrip("/")


def path_matches_any(rel_posix: str, patterns: Sequence[str]) -> bool:
    if not patterns:
        return False
    rel_path = PurePosixPath(rel_posix)
    for pattern in patterns:
        if pattern in {"**", "**/*"}:
            return True
        if fnmatch.fnmatch(rel_posix, pattern):
            return True
        if rel_path.match(pattern):
            return True
    return False


def should_include(rel_posix: str, include_globs: Sequence[str], exclude_globs: Sequence[str]) -> bool:
    if path_matches_any(rel_posix, exclude_globs):
        return False
    return path_matches_any(rel_posix, include_globs)


def sha256_file(path: Path, chunk_size: int = 1024 * 1024) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def build_manifest(
    root_dir: Path,
    include_globs: Sequence[str],
    exclude_globs: Sequence[str],
    verify_hash: bool,
    skip_symlinks: bool,
    logger: Optional[logging.Logger] = None,
) -> list[FileManifestEntry]:
    root_dir = root_dir.resolve()
    if not root_dir.exists() or not root_dir.is_dir():
        raise TransferError(f"source_dir must exist and be a directory: {root_dir}")

    entries: list[FileManifestEntry] = []
    for path in sorted(root_dir.rglob("*"), key=lambda p: p.relative_to(root_dir).as_posix()):
        rel = normalize_rel_path(path.relative_to(root_dir))
        if path.is_symlink():
            if skip_symlinks:
                if logger:
                    logger.warning("Skipping symlink: %s", path)
                continue
            raise TransferError(f"Symlink is not supported by default: {path}")
        if not should_include(rel, include_globs, exclude_globs):
            continue
        try:
            st = path.stat()
        except OSError as exc:
            raise TransferError(f"Cannot stat path for manifest: {path}: {exc}") from exc
        if path.is_dir():
            entries.append(
                FileManifestEntry(
                    relative_path=rel,
                    kind="directory",
                    size=0,
                    sha256=None,
                    mtime_ns=st.st_mtime_ns,
                )
            )
        elif path.is_file():
            entries.append(
                FileManifestEntry(
                    relative_path=rel,
                    kind="file",
                    size=st.st_size,
                    sha256=sha256_file(path) if verify_hash else None,
                    mtime_ns=st.st_mtime_ns,
                )
            )
        else:
            raise TransferError(f"Unsupported filesystem entry type: {path}")
    return entries


def manifest_to_jsonable(entries: Sequence[FileManifestEntry]) -> list[dict[str, Any]]:
    return [dataclass_to_plain(entry) for entry in entries]


# =============================================================================
# Locking
# =============================================================================


def lock_file_path_for(source_dir: Path) -> Path:
    source_dir = source_dir.resolve()
    return source_dir.parent / f".remote_job_runner_{sanitize_filename(source_dir.name)}.lock"


@contextlib.contextmanager
def acquire_lock(source_dir: Path) -> Iterator[Path]:
    lock_path = lock_file_path_for(source_dir)
    payload = {
        "pid": os.getpid(),
        "timestamp": utc_now_iso(),
        "source_dir": str(source_dir.resolve()),
    }
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    try:
        fd = os.open(str(lock_path), flags, 0o600)
    except FileExistsError as exc:
        raise LockError(f"Lock already exists: {lock_path}. Another job may be running.") from exc
    except OSError as exc:
        raise LockError(f"Cannot create lock file: {lock_path}: {exc}") from exc

    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2)
        yield lock_path
    finally:
        try:
            lock_path.unlink(missing_ok=True)
        except OSError:
            logging.getLogger(__name__).warning("Failed to remove lock file: %s", lock_path, exc_info=True)


# =============================================================================
# SFTP helpers
# =============================================================================


def remote_stat_exists(sftp: Any, remote_path: str) -> bool:
    try:
        sftp.stat(remote_path)
        return True
    except FileNotFoundError:
        return False
    except IOError as exc:
        # Paramiko commonly raises IOError/OSError for missing remote paths.
        errno_value = getattr(exc, "errno", None)
        if errno_value == 2:
            return False
        return False


def remote_mkdir_p(sftp: Any, remote_dir: str) -> None:
    remote_dir = posixpath.normpath(remote_dir)
    if remote_dir in {"/", ".", ""}:
        return
    parts = remote_dir.strip("/").split("/")
    current = "/" if remote_dir.startswith("/") else ""
    for part in parts:
        current = posixpath.join(current, part) if current else part
        try:
            sftp.stat(current)
        except Exception:
            sftp.mkdir(current)


def remote_remove_tree(sftp: Any, remote_path: str, logger: Optional[logging.Logger] = None) -> None:
    try:
        attrs = sftp.stat(remote_path)
    except Exception:
        return
    if stat_mod.S_ISDIR(attrs.st_mode):
        for child in sftp.listdir_attr(remote_path):
            child_path = posixpath.join(remote_path, child.filename)
            if stat_mod.S_ISDIR(child.st_mode):
                remote_remove_tree(sftp, child_path, logger)
            else:
                sftp.remove(child_path)
        sftp.rmdir(remote_path)
    else:
        sftp.remove(remote_path)
    if logger:
        logger.debug("Removed remote path: %s", remote_path)


def create_remote_workdir(sftp: Any, remote_base_dir: str, job_id: str) -> str:
    remote_base_dir = posixpath.normpath(remote_base_dir)
    remote_mkdir_p(sftp, remote_base_dir)
    remote_workdir = posixpath.join(remote_base_dir, job_id)
    if remote_stat_exists(sftp, remote_workdir):
        raise TransferError(f"Remote working directory already exists: {remote_workdir}")
    sftp.mkdir(remote_workdir)
    return remote_workdir


def upload_manifest_entries(
    sftp: Any,
    local_root: Path,
    remote_workdir: str,
    manifest: Sequence[FileManifestEntry],
    logger: logging.Logger,
) -> None:
    local_root = local_root.resolve()
    for entry in manifest:
        remote_path = posixpath.join(remote_workdir, entry.relative_path)
        if entry.kind == "directory":
            remote_mkdir_p(sftp, remote_path)
        elif entry.kind == "file":
            remote_mkdir_p(sftp, posixpath.dirname(remote_path))
            local_path = local_root / entry.relative_path
            logger.debug("Uploading %s -> %s", local_path, remote_path)
            try:
                sftp.put(str(local_path), remote_path)
            except Exception as exc:
                raise TransferError(f"Failed to upload {local_path} -> {remote_path}: {exc}") from exc
        else:  # pragma: no cover - kind is restricted by dataclass type
            raise TransferError(f"Unsupported manifest entry kind: {entry.kind}")


def download_remote_tree(sftp: Any, remote_root: str, local_root: Path, logger: logging.Logger) -> None:
    local_root.mkdir(parents=True, exist_ok=True)
    try:
        children = sftp.listdir_attr(remote_root)
    except Exception as exc:
        raise TransferError(f"Cannot list remote directory: {remote_root}: {exc}") from exc

    for child in children:
        remote_child = posixpath.join(remote_root, child.filename)
        local_child = local_root / child.filename
        if stat_mod.S_ISDIR(child.st_mode):
            local_child.mkdir(parents=True, exist_ok=True)
            download_remote_tree(sftp, remote_child, local_child, logger)
        else:
            local_child.parent.mkdir(parents=True, exist_ok=True)
            logger.debug("Downloading %s -> %s", remote_child, local_child)
            try:
                sftp.get(remote_child, str(local_child))
            except Exception as exc:
                raise TransferError(f"Failed to download {remote_child} -> {local_child}: {exc}") from exc


# =============================================================================
# SSH and command execution
# =============================================================================


def ensure_paramiko_available() -> Any:
    if paramiko is None:
        raise ConnectionError("Missing dependency: paramiko. Install with: pip install paramiko")
    return paramiko


def connect_ssh(config: ResolvedConfig, password: Optional[str], logger: logging.Logger) -> Any:
    pm = ensure_paramiko_available()
    client = pm.SSHClient()
    client.load_system_host_keys()
    if config.auto_add_host_key:
        logger.warning("--auto-add-host-key enabled. Unknown SSH host keys will be trusted automatically. This is less secure.")
        client.set_missing_host_key_policy(pm.AutoAddPolicy())
    else:
        client.set_missing_host_key_policy(pm.RejectPolicy())

    connect_kwargs: dict[str, Any] = {
        "hostname": config.remote.host,
        "port": config.remote.port,
        "username": config.remote.username,
        "timeout": 30,
        "banner_timeout": 30,
        "auth_timeout": 30,
    }
    if config.auth.key_file is not None:
        connect_kwargs["key_filename"] = str(config.auth.key_file)
    if password is not None:
        connect_kwargs["password"] = password

    try:
        client.connect(**connect_kwargs)
    except Exception as exc:
        raise ConnectionError(f"SSH connection failed for {config.remote.username}@{config.remote.host}:{config.remote.port}: {exc}") from exc
    return client


def make_remote_shell_command(remote_workdir: str, command: str) -> str:
    return f"cd {shlex.quote(remote_workdir)} && bash -lc {shlex.quote(command)}"


def read_stream_text(stream: Any) -> str:
    try:
        data = stream.read()
    except Exception:
        return ""
    if isinstance(data, bytes):
        return data.decode("utf-8", errors="replace")
    return str(data)


def run_remote_command(
    ssh_client: Any,
    remote_workdir: str,
    command_spec: CommandSpec,
    stage_name: str,
    log_dir: Path,
    logger: logging.Logger,
) -> CommandResult:
    command_to_run = make_remote_shell_command(remote_workdir, command_spec.cmd)
    start_time = utc_now_iso()
    start = time.monotonic()
    stdout_text = ""
    stderr_text = ""
    exit_code = 255
    timed_out = False

    logger.info("Starting command [%s/%s]: %s", stage_name, command_spec.name, command_spec.cmd)
    try:
        stdin, stdout, stderr = ssh_client.exec_command(command_to_run, get_pty=False)
        try:
            stdin.close()
        except Exception:
            pass
        channel = stdout.channel
        while not channel.exit_status_ready():
            if time.monotonic() - start > command_spec.timeout_sec:
                timed_out = True
                exit_code = 124
                try:
                    channel.close()
                except Exception:
                    pass
                break
            time.sleep(0.1)
        if not timed_out:
            exit_code = int(channel.recv_exit_status())
        stdout_text = read_stream_text(stdout)
        stderr_text = read_stream_text(stderr)
    except socket.timeout as exc:
        timed_out = True
        exit_code = 124
        stderr_text += f"\nCommand timed out: {exc}"
    except Exception as exc:
        exit_code = 255
        stderr_text += f"\nCommand execution failed: {exc}"

    end = time.monotonic()
    end_time = utc_now_iso()
    result = CommandResult(
        stage_name=stage_name,
        command_name=command_spec.name,
        command=command_spec.cmd,
        start_time=start_time,
        end_time=end_time,
        duration_sec=round(end - start, 6),
        exit_code=exit_code,
        stdout=stdout_text,
        stderr=stderr_text,
        timed_out=timed_out,
    )
    write_command_log(result, log_dir)
    if result.success:
        logger.info("Command succeeded [%s/%s] in %.2fs", stage_name, command_spec.name, result.duration_sec)
    else:
        logger.error(
            "Command failed [%s/%s]: exit_code=%s timed_out=%s duration=%.2fs",
            stage_name,
            command_spec.name,
            result.exit_code,
            result.timed_out,
            result.duration_sec,
        )
    return result


def write_command_log(result: CommandResult, log_dir: Path) -> None:
    stdout_stderr_dir = log_dir / "stdout_stderr"
    stdout_stderr_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{sanitize_filename(result.stage_name)}_{sanitize_filename(result.command_name)}.log"
    body = [
        f"stage: {result.stage_name}",
        f"command_name: {result.command_name}",
        f"command: {result.command}",
        f"start_time: {result.start_time}",
        f"end_time: {result.end_time}",
        f"duration_sec: {result.duration_sec}",
        f"exit_code: {result.exit_code}",
        f"timed_out: {result.timed_out}",
        "",
        "===== STDOUT =====",
        result.stdout,
        "",
        "===== STDERR =====",
        result.stderr,
        "",
    ]
    (stdout_stderr_dir / filename).write_text("\n".join(body), encoding="utf-8")


def run_stage(
    ssh_client: Any,
    remote_workdir: str,
    stage_spec: StageSpec,
    log_dir: Path,
    logger: logging.Logger,
    command_runner: Optional[Callable[[Any, str, CommandSpec, str, Path, logging.Logger], CommandResult]] = None,
) -> StageResult:
    runner = command_runner or run_remote_command
    logger.info("Starting stage: %s (%s)", stage_spec.name, stage_spec.mode)

    if stage_spec.mode == "sequential":
        results: list[CommandResult] = []
        for command in stage_spec.commands:
            result = runner(ssh_client, remote_workdir, command, stage_spec.name, log_dir, logger)
            results.append(result)
            if not result.success:
                logger.error("Stopping sequential stage after failed command: %s", command.name)
                return StageResult(stage_name=stage_spec.name, mode=stage_spec.mode, command_results=results, success=False)
        return StageResult(stage_name=stage_spec.name, mode=stage_spec.mode, command_results=results, success=True)

    if stage_spec.mode == "parallel":
        max_workers = stage_spec.max_workers or min(4, len(stage_spec.commands))
        if max_workers < 1:
            raise ConfigError(f"Stage '{stage_spec.name}' requires max_workers >= 1")
        indexed_results: dict[int, CommandResult] = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_index = {
                executor.submit(runner, ssh_client, remote_workdir, command, stage_spec.name, log_dir, logger): index
                for index, command in enumerate(stage_spec.commands)
            }
            for future in concurrent.futures.as_completed(future_to_index):
                index = future_to_index[future]
                try:
                    indexed_results[index] = future.result()
                except Exception as exc:
                    command = stage_spec.commands[index]
                    now = utc_now_iso()
                    indexed_results[index] = CommandResult(
                        stage_name=stage_spec.name,
                        command_name=command.name,
                        command=command.cmd,
                        start_time=now,
                        end_time=now,
                        duration_sec=0.0,
                        exit_code=255,
                        stdout="",
                        stderr=f"Command runner raised exception: {exc}",
                        timed_out=False,
                    )
                    write_command_log(indexed_results[index], log_dir)
        results = [indexed_results[index] for index in range(len(stage_spec.commands))]
        success = all(result.success for result in results)
        return StageResult(stage_name=stage_spec.name, mode=stage_spec.mode, command_results=results, success=success)

    raise ConfigError(f"Unsupported stage mode: {stage_spec.mode}")


# =============================================================================
# Verification and safe swap
# =============================================================================


def verify_downloaded_manifest(result_manifest: Sequence[FileManifestEntry]) -> None:
    """Basic self-verification hook for downloaded contents.

    Remote commands are allowed to add, delete, or modify files, so the downloaded
    result does not need to match the upload manifest. This function verifies that
    the manifest is internally well-formed and non-contradictory.
    """
    seen: set[str] = set()
    for entry in result_manifest:
        if entry.relative_path in seen:
            raise VerificationError(f"Duplicate manifest path after download: {entry.relative_path}")
        seen.add(entry.relative_path)
        if not entry.relative_path or entry.relative_path.startswith("/") or ".." in PurePosixPath(entry.relative_path).parts:
            raise VerificationError(f"Unsafe manifest relative path: {entry.relative_path}")
        if entry.kind == "file" and entry.size < 0:
            raise VerificationError(f"Invalid file size in manifest: {entry.relative_path}")


def safe_replace_source_dir(source_dir: Path, result_dir: Path, backup_dir: Path, keep_backup: bool, logger: Optional[logging.Logger] = None) -> None:
    source_dir = source_dir.resolve()
    result_dir = result_dir.resolve()
    backup_dir = backup_dir.resolve()
    if not source_dir.exists() or not source_dir.is_dir():
        raise SafeSwapError(f"source_dir does not exist or is not a directory: {source_dir}")
    if not result_dir.exists() or not result_dir.is_dir():
        raise SafeSwapError(f"result_dir does not exist or is not a directory: {result_dir}")
    if backup_dir.exists():
        raise SafeSwapError(f"backup_dir already exists: {backup_dir}")

    log = logger or logging.getLogger(__name__)
    log.info("Safe swap: renaming source_dir -> backup_dir: %s -> %s", source_dir, backup_dir)
    try:
        source_dir.rename(backup_dir)
    except OSError as exc:
        raise SafeSwapError(f"Failed to rename source_dir to backup_dir: {source_dir} -> {backup_dir}: {exc}") from exc

    try:
        log.info("Safe swap: renaming result_dir -> source_dir: %s -> %s", result_dir, source_dir)
        result_dir.rename(source_dir)
    except OSError as exc:
        rollback_error: Optional[BaseException] = None
        try:
            if source_dir.exists():
                # Leave it in place for manual inspection; moving it could be more destructive.
                raise SafeSwapError(f"Rollback blocked because source_dir path now exists: {source_dir}")
            backup_dir.rename(source_dir)
        except BaseException as rollback_exc:  # noqa: BLE001 - preserving failure context for manual repair
            rollback_error = rollback_exc
        if rollback_error is None:
            raise SafeSwapError(
                f"Failed to promote result_dir to source_dir, but rollback succeeded. "
                f"Result remains at: {result_dir}. Original restored at: {source_dir}. Original error: {exc}"
            ) from exc
        raise SafeSwapError(
            "Safe swap failed and rollback also failed. Manual repair required. "
            f"source_dir={source_dir}, backup_dir={backup_dir}, result_dir={result_dir}, "
            f"promote_error={exc}, rollback_error={rollback_error}"
        ) from exc

    if not keep_backup:
        try:
            log.info("Deleting backup because keep_backup=false: %s", backup_dir)
            shutil.rmtree(backup_dir)
        except OSError:
            log.warning("Failed to delete backup. New source_dir is intact; backup remains at: %s", backup_dir, exc_info=True)


# =============================================================================
# Logs and dry-run output
# =============================================================================


def make_log_dir(source_dir: Path, job_id: str) -> Path:
    return source_dir.resolve().parent / ".remote_job_runner_logs" / job_id


def configure_logging(log_dir: Path, verbose: bool) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("remote_job_runner")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)
    logger.handlers.clear()
    logger.propagate = False

    formatter = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")

    console = logging.StreamHandler(sys.stderr)
    console.setLevel(logging.DEBUG if verbose else logging.INFO)
    console.setFormatter(formatter)
    logger.addHandler(console)

    file_handler = logging.FileHandler(log_dir / "job.log", encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    return logger


def build_plan_dict(config: ResolvedConfig, job_id: str, manifest: Sequence[FileManifestEntry]) -> dict[str, Any]:
    source_dir = config.job.source_dir.resolve()
    remote_workdir = posixpath.join(posixpath.normpath(config.remote.remote_base_dir), job_id)
    backup_dir = source_dir.with_name(f"{source_dir.name}.backup_{job_id}")
    return {
        "source_dir": str(source_dir),
        "remote": {
            "host": config.remote.host,
            "port": config.remote.port,
            "username": config.remote.username,
            "remote_base_dir": config.remote.remote_base_dir,
            "remote_workdir": remote_workdir,
        },
        "local": {
            "log_dir": str(make_log_dir(source_dir, job_id)),
            "backup_dir": str(backup_dir),
            "lock_file": str(lock_file_path_for(source_dir)),
        },
        "policy": {
            "keep_backup": config.job.keep_backup,
            "cleanup_remote_on_success": config.job.cleanup_remote_on_success,
            "cleanup_remote_on_failure": config.job.cleanup_remote_on_failure,
            "verify_hash": config.job.verify_hash,
            "skip_symlinks": config.job.skip_symlinks,
            "auto_add_host_key": config.auto_add_host_key,
        },
        "transfer": {
            "include_globs": config.transfer.include_globs,
            "exclude_globs": config.transfer.exclude_globs,
            "upload_entries": manifest_to_jsonable(manifest),
        },
        "stages": [dataclass_to_plain(stage) for stage in config.stages],
    }


def print_dry_run_plan(config: ResolvedConfig, job_id: str, manifest: Sequence[FileManifestEntry]) -> None:
    plan = build_plan_dict(config, job_id, manifest)
    print(json.dumps(plan, indent=2, ensure_ascii=False))


def confirm_or_exit(yes: bool) -> None:
    if yes:
        return
    response = input("Proceed? [y/N] ").strip().lower()
    if response not in {"y", "yes"}:
        raise SystemExit("Cancelled by user.")


# =============================================================================
# Job runner
# =============================================================================


def run_job(config: ResolvedConfig, *, dry_run: bool, yes: bool, verbose: bool) -> JobResult:
    job_id = make_job_id()
    source_dir = config.job.source_dir.resolve()
    log_dir = make_log_dir(source_dir, job_id)

    # Dry-run should not create log dir or lock. It may scan source_dir, which is read-only.
    dry_logger = logging.getLogger("remote_job_runner_dry_run")
    manifest = build_manifest(
        source_dir,
        config.transfer.include_globs,
        config.transfer.exclude_globs,
        config.job.verify_hash,
        config.job.skip_symlinks,
        dry_logger,
    )

    if dry_run:
        print_dry_run_plan(config, job_id, manifest)
        return JobResult(
            job_id=job_id,
            success=True,
            remote_workdir=posixpath.join(posixpath.normpath(config.remote.remote_base_dir), job_id),
            local_log_dir=log_dir,
            backup_dir=None,
            stage_results=[],
        )

    logger = configure_logging(log_dir, verbose)
    logger.info("Starting job: %s", job_id)
    if config.auto_add_host_key:
        logger.warning("auto_add_host_key is enabled; this lowers SSH host key security.")

    dump_resolved_config(config, log_dir / "config.resolved.yaml")
    write_json(log_dir / "manifest.before_upload.json", manifest_to_jsonable(manifest))
    confirm_or_exit(yes)

    stage_results: list[StageResult] = []
    remote_workdir = posixpath.join(posixpath.normpath(config.remote.remote_base_dir), job_id)
    backup_dir = source_dir.with_name(f"{source_dir.name}.backup_{job_id}")
    password: Optional[str] = None
    ssh_client: Any = None
    sftp: Any = None
    success = False

    with acquire_lock(source_dir):
        try:
            password = resolve_password(config.auth)
            ssh_client = connect_ssh(config, password, logger)
            sftp = ssh_client.open_sftp()
            remote_workdir = create_remote_workdir(sftp, config.remote.remote_base_dir, job_id)
            logger.info("Created remote working directory: %s", remote_workdir)

            upload_manifest_entries(sftp, source_dir, remote_workdir, manifest, logger)
            logger.info("Upload completed: %d manifest entries", len(manifest))

            for stage in config.stages:
                stage_result = run_stage(ssh_client, remote_workdir, stage, log_dir, logger)
                stage_results.append(stage_result)
                write_json(log_dir / "commands.json", [dataclass_to_plain(result) for result in stage_results])
                if not stage_result.success:
                    raise RemoteCommandError(f"Stage failed: {stage.name}")

            with tempfile.TemporaryDirectory(prefix=f"{job_id}_result_") as tmp:
                result_dir = Path(tmp) / "result"
                download_remote_tree(sftp, remote_workdir, result_dir, logger)
                after_manifest = build_manifest(
                    result_dir,
                    ["**/*"],
                    [],
                    config.job.verify_hash,
                    config.job.skip_symlinks,
                    logger,
                )
                verify_downloaded_manifest(after_manifest)
                write_json(log_dir / "manifest.after_download.json", manifest_to_jsonable(after_manifest))

                # TemporaryDirectory would delete result_dir at exit; move it out before safe swap.
                staged_result_dir = source_dir.parent / f".{source_dir.name}.result_{job_id}"
                if staged_result_dir.exists():
                    raise SafeSwapError(f"Staged result directory already exists: {staged_result_dir}")
                result_dir.rename(staged_result_dir)
                safe_replace_source_dir(source_dir, staged_result_dir, backup_dir, config.job.keep_backup, logger)

            success = True
            if config.job.cleanup_remote_on_success:
                try:
                    remote_remove_tree(sftp, remote_workdir, logger)
                    logger.info("Cleaned remote working directory: %s", remote_workdir)
                except Exception:
                    logger.warning("Failed to clean remote working directory after success: %s", remote_workdir, exc_info=True)
            logger.info("Job succeeded: %s", job_id)

        except Exception as exc:
            logger.error("Job failed: %s", exc, exc_info=True)
            if sftp is not None and config.job.cleanup_remote_on_failure:
                try:
                    remote_remove_tree(sftp, remote_workdir, logger)
                    logger.info("Cleaned remote working directory after failure: %s", remote_workdir)
                except Exception:
                    logger.warning("Failed to clean remote working directory after failure: %s", remote_workdir, exc_info=True)
            raise
        finally:
            password = None
            if sftp is not None:
                try:
                    sftp.close()
                except Exception:
                    pass
            if ssh_client is not None:
                try:
                    ssh_client.close()
                except Exception:
                    pass

    return JobResult(
        job_id=job_id,
        success=success,
        remote_workdir=remote_workdir,
        local_log_dir=log_dir,
        backup_dir=backup_dir if backup_dir.exists() else None,
        stage_results=stage_results,
    )


# =============================================================================
# CLI
# =============================================================================


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="remote_job_runner.py",
        description="Stage a local folder on a remote workstation, run staged commands, and safely return results.",
    )
    parser.add_argument("--config", required=True, help="Path to YAML config file.")
    parser.add_argument("--host", help="Override remote.host.")
    parser.add_argument("--port", type=int, help="Override remote.port.")
    parser.add_argument("--username", help="Override remote.username.")
    parser.add_argument("--password-env", help="Override auth.password_env.")
    parser.add_argument("--key-file", help="Override auth.key_file.")
    parser.add_argument("--source-dir", help="Override job.source_dir.")
    parser.add_argument("--remote-base-dir", help="Override remote.remote_base_dir.")
    parser.add_argument("--dry-run", action="store_true", help="Print plan only; do not modify local or remote filesystem.")
    parser.add_argument("--verbose", action="store_true", help="Enable DEBUG logging.")
    parser.add_argument("--yes", action="store_true", help="Skip execution confirmation prompt.")
    backup_group = parser.add_mutually_exclusive_group()
    backup_group.add_argument("--keep-backup", dest="keep_backup", action="store_true", default=None, help="Keep local backup after successful swap.")
    backup_group.add_argument("--no-keep-backup", dest="keep_backup", action="store_false", help="Delete local backup after successful swap.")

    cleanup_success_group = parser.add_mutually_exclusive_group()
    cleanup_success_group.add_argument(
        "--cleanup-remote-on-success",
        dest="cleanup_remote_on_success",
        action="store_true",
        default=None,
        help="Delete remote working directory after successful job.",
    )
    cleanup_success_group.add_argument(
        "--no-cleanup-remote-on-success",
        dest="cleanup_remote_on_success",
        action="store_false",
        help="Keep remote working directory after successful job.",
    )

    cleanup_failure_group = parser.add_mutually_exclusive_group()
    cleanup_failure_group.add_argument(
        "--cleanup-remote-on-failure",
        dest="cleanup_remote_on_failure",
        action="store_true",
        default=None,
        help="Delete remote working directory after failed job.",
    )
    cleanup_failure_group.add_argument(
        "--no-cleanup-remote-on-failure",
        dest="cleanup_remote_on_failure",
        action="store_false",
        help="Keep remote working directory after failed job.",
    )

    parser.add_argument(
        "--auto-add-host-key",
        action="store_true",
        help="Trust unknown SSH host keys automatically. Less secure; disabled by default.",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        config = load_config(Path(args.config), args)
        result = run_job(config, dry_run=args.dry_run, yes=args.yes, verbose=args.verbose)
        if args.dry_run:
            return 0
        print(json.dumps(dataclass_to_plain(result), indent=2, ensure_ascii=False))
        return 0
    except SystemExit:
        raise
    except RemoteJobRunnerError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    except KeyboardInterrupt:
        print("ERROR: Interrupted by user.", file=sys.stderr)
        return 130
    except Exception as exc:  # noqa: BLE001 - CLI guardrail
        print(f"UNEXPECTED ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
