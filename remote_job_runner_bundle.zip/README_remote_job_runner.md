# remote_job_runner

`remote_job_runner.py` stages a local folder on a remote Linux workstation, executes configured sequential/parallel command stages over SSH, downloads the remote working directory, verifies the downloaded result manifest, and safely swaps it back into the original local path.

## Install

```bash
pip install -r requirements.txt
```

## Dry run

```bash
python remote_job_runner.py --config config.example.yaml --dry-run
```

Dry-run prints the plan only. It does not create locks, connect SSH, upload, execute commands, download, delete, or rename folders.

## Run

```bash
python remote_job_runner.py --config config.yaml --yes
```

## Authentication

Prefer SSH key auth:

```yaml
auth:
  key_file: "~/.ssh/id_ed25519"
```

For password auth, do not write the password in YAML. Use an environment variable:

```bash
export WORKSTATION_PASSWORD='your-password'
```

```yaml
auth:
  password_env: "WORKSTATION_PASSWORD"
```

If neither `key_file` nor `password_env` is configured, the CLI asks interactively via `getpass`.

## Stages

- `sequential`: commands run in order. The stage stops on the first failing command.
- `parallel`: commands run concurrently with `max_workers`. The stage fails if any command fails or times out.

All commands run inside the remote working directory.

## Safe swap

The tool does not directly delete `source_dir`. After successful remote execution and download verification, it performs:

1. Rename original `source_dir` to `<source_dir>.backup_<job_id>`.
2. Rename downloaded result directory to `source_dir`.
3. If promotion fails, attempt rollback.
4. Delete backup only when `keep_backup: false`.

## Host key policy

By default, unknown SSH host keys are rejected. `--auto-add-host-key` is available but weakens SSH host key verification and should only be used in controlled environments.

## Known limitations

- Uses recursive SFTP, not rsync.
- No interrupted transfer resume.
- Symlinks are unsupported by default.
- Parallel commands can race if they write the same files; users must coordinate command behavior.
- Remote shell commands are trusted input. The tool records and executes them; it does not semantically audit command safety.
